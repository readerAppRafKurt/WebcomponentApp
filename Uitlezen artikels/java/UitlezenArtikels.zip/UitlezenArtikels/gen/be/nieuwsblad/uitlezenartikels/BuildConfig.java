/** Automatically generated file. DO NOT MODIFY */
package be.nieuwsblad.uitlezenartikels;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}